﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.WinFormsExample")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © Anthony Taranto 2012")]

[assembly: AssemblyVersion("0.9.*")]
[assembly: ComVisible(false)]
