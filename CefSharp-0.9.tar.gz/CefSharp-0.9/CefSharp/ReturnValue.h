#pragma once

namespace CefSharp
{
    public enum class ReturnValue
    {
        Handled = 0,
        Continue
    };
}